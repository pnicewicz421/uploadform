from sys import argv

script, filename = argv

def print_all(filename):
	print filename.read()
	
def rewind(filename):
	filename.seek(0, 0)
	
def print_a_line(filename, fileline):
	print fileline, filename.readline(fileline)
	
def check_position(filename):
	print "You are in position %s" % filename.tell()

current_file = open(filename, "r")

resp = 0

while resp <> 4:
	resp = int(raw_input("Which options would you like?\n0) Print_All\n1) Rewind\n2) Print a Line\n3) Check Position\n4) Quit"))
	if resp == 0:
		print_all(current_file)
	elif resp == 1:
		rewind(current_file)
	elif resp == 2:
		linenumber = int(raw_input("Which line number?"))
		print_a_line(current_file, linenumber)
	elif resp == 3:
		check_position(current_file)

	
