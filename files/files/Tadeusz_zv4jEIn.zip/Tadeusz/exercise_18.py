def print_two(*args):
	for i in args:
		print "%r" % i,
		
	#print "arg1: %r, arg2 %r %r" % args
	#print "arg1: %r, arg2 %r" % (arg1, arg2)
	
def print_two_lines (arg1, arg2):
	print "arg1: %r, arg2: %r" % (arg1, arg2)
	
print_two_lines("Mama", "Tata")
	