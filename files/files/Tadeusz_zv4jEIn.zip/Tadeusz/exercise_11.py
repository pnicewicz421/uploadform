print "How old are you?",
age = raw_input(int)
print "How tall are you?", 
height = raw_input(int)
print "How much do you weigh?",
weight = raw_input(int)

print "You are %s old %s tall and %s heavy." % (age, height, weight)