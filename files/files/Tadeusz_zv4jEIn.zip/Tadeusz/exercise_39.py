state = {
	'Oregon': 'OR',
	'Florida': 'FL',
	'California': 'CA',
	'New York': 'NY',
	'Michigan': 'MI',
}

cities = {
	'CA': 'Sacramento',
	'MI': 'Lansig',
	'FL': 'Tallahassee',
}
	
cities['NY'] = 'Albany'
cities['OR'] = 'Eugene'


print '-' * 10
while True:
	print 'Give me a state abbreviation'
	r = raw_input("> ")

	capital = cities.get(r)

	if not capital:
		print "I don't know that one."
		print "Tell me what it is so that I can learn it."
		x = raw_input("> ")
	
		cities[r] = x
		print "I have now learned that the capital of %s is %s." % (r, x)
	else:
		print "The capital of %s is %s" % (r, capital)
	
