def new(num_buckets=256):
	keyMap = []
	valueMap = []
	for i in range(0, num_buckets):
		keyMap.append([])
		valueMap.append([])
	return keyMap, valueMap

def hash_key(aMap, key):
	#hash key mod number of items in map ... i.e., identify a slots
	print "-" *25
	print "hash_key function, generates an index for the map"
	print "The content of aMap is: ", aMap
	print "The content of key is: ", key
	print "The hash key of key is: ", hash(key)
	print "The length of aMap is: ", len(aMap)
	print "The resulting hash_key (bucket_id) is: ", hash(key) % len(aMap)
	
	return hash(key) % len(aMap)
	
def get_bucket(aMap, key):
	print "-" *25
	print "get_bucket function"
	print "Given a key, find the bucket"
	bucket_id = hash_key(aMap, key)
	print "I am returning aMap[bucket_id] (value in aMap, i.e., a slot): ", aMap[bucket_id]
	return aMap[bucket_id]

def get_slot(aMap, key, default=None):

	bucket = get_bucket(aMap, key)

			
def get(aMap, key, default=None):

	i, k, v = get_slot(aMap, key, default=default)
	print "Here is value: ", k[key]

	return k[key]

def set(aMap, key, value):
	
	bucket = get_bucket(aMap, key)
	if key in key_list:
		
	
	k[key].append(value)
	
	#i, k, v = get_slot(aMap, key)
#
#	if i >= 0:
#		print "key exists. I am planting (%s, %s)" % (key, value)
#		print "in bucket[i]. bucket[i]: ", bucket[i]
#		bucket[i] = (key, value)
#	else:
#		print "Key does not exist. Setting a new one"
#		bucket.append((key, value))
		
def delete(aMap, key):
	bucket = get_bucket(aMap, key)
	
	for i in xrange(len(bucket)):
		k, v = bucket[i]
		if key == k:
			del bucket[i]
			break

def list(aMap):
	print "--"*25
	print "Printing out the aMap list"
	for bucket in aMap:
		if bucket:
			for k,v in bucket:
				print k, v