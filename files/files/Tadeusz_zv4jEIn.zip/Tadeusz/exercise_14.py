from sys import argv

script, username = argv

prompt = '> '
print 'Hi %s, I\'m the %s script.' % (username, script)
print 'What is your favorite color, %s?' % username
favcolor = raw_input(prompt)

print 'How old are you, %s?' % username
age = raw_input(prompt)

print 'What is your middle name, %s?' % username
middlename = raw_input(prompt)

print """
	Here's what I know about you:
	Your name is %s
	Your favorite color is %s
	You are %s years old
	Your middle name is %s
""" % (username, favcolor, age, middlename)