from sys import argv

script, filename = argv

print "We are going to ERASE %r" % filename
print "Press Q to quit or press anything else to continue"
res = raw_input("> ")

if res == "Q":
	print "Good job! You've managed to rescue your file."
	quit() #Lesson I learned: quit() quits the program	
else:
	print "Haha! Your file %r is going to get erased!" % filename
	target = open(filename, "w+") #Lesson I learned: you need w mode 
								  #to truncate and w+ or r+ to read and truncate
	
	target.read()
	target.truncate()
	
print "Now give me three lines."
line1 = raw_input("Line 1:")
line2 = raw_input("Line 2:")
line3 = raw_input("Line 3:")
txt_write = "%s \n %s \n %s" % (line1, line2, line3) 
target.write(txt_write) #Lesson I learned: you can't used tuples in write
target.read()
target.close()