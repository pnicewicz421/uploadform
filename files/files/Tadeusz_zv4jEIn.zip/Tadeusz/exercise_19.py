def cheese_and_crackers(cheese, crackers):
	print "You have %s slices of cheese" % cheese
	print "You have %s crackers" % crackers
	
def slicer(cubes):  #This cuts the cubes of cheese to a party
	"This cuts the cubes of cheese to a party"
	cubes = cubes + 2
	print "Inside function you have %s cubes" % cubes
	#slices = cubes * power
	#return slices
	return cubes
	
def open_crackers(boxes, size):
	crackers = boxes * size
	#return crackers
	
cubes = int(raw_input("How many cubes of cheese do you have? "))
power_slicer = int(raw_input("How many slices would you like per cube?"))
cracker_boxes = int(raw_input("How many boxes of crackers would you like?"))
amt_in_a_box = int(raw_input("How many crackers are in a box?"))

#slices = 
slicer(cubes)
print "Outside you have %s cubes!" % cubes
#print "You have %s slices" % slices

#crackers = 
#open_crackers(cracker_boxes, amt_in_a_box)
#print "You have %s crackers" % crackers

#cheese_and_crackers(slices, crackers)

