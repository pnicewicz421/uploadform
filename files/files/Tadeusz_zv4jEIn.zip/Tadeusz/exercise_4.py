def appr(average_passengers_per_car):
	"Print out average passenger per car"
	print "On average, we will have %s passengers per car." % average_passengers_per_car

#def black_magic(passengers, cars, space_in_a_car): 
	#carpool_capacity = int(carpool_capacity)
	#cars = int(cars)
	#space_in_a_car = int(space_in_a_car)
	#if passengers <= space_in_a_car:
	#	print "1 car will fit all of the passengers"
	
	
	#i = passengers - cars + 1 
	#c
	#car_list = []
	#for counter in range (0, cars):         #create a list with car numbers of elements
	#	if counter == 0:
	#		car_list.append(i)
	#	else:
	#		car_list.append(1)
	#print car_list
	
	#if len(car_list[y:])==list.count(
	

print "Cars: ",
cars = float(raw_input())
print "Space in a Car:",
space_in_a_car = float(raw_input())
print "Drivers:",
drivers = float(raw_input())
print "Passengers:",
passengers = float(raw_input())

# We need to figure out the limiting factor of how many cars 
# will be driven, i.e., cars or drivers

if cars >= drivers:        #Because there are more cars, drivers are the limiting factor
	cars_driven = drivers
	cars_not_driven = cars - drivers

else:                      #Cars are the limiting factor
	cars_driven = cars
	cars_not_driven = 0

carpool_capacity = cars_driven * space_in_a_car        #How many we can transport 

print "\nThere are %s cars available." % cars
print "\nThere are %s drivers available." % drivers
print "\n%s cars will be driven." % cars_driven
print "\nThere will be %s empty cars today." % cars_not_driven
print "\nWe can transport %s people today." % carpool_capacity
print "\nWe have %s to carpool today." % passengers
#print "\nWe need to put about %s in each car." % average_passengers_per_car 

#Figure out limiting factor of passengers per car, 
#i.e., space in a car or passengers
if carpool_capacity >= passengers:       
	extra_seats = carpool_capacity - passengers       
	average_passengers_per_car = passengers / cars_driven    
	print "Hooray! We can transport everyone today!"
	print "We will even have %s extra seats available." % extra_seats
	appr(average_passengers_per_car)
	
	black_magic(carpool_capacity, cars_driven, space_in_a_car)
else:
	remaining_passengers = passengers - carpool_capacity
	average_passengers_per_car = carpool_capacity / cars_driven
	print "Oh no! We will have %s people left over." % remaining_passengers
	
	if remaining_passengers % space_in_a_car == 0: 
		extra_drivers = remaining_passengers / space_in_a_car
	else:
		extra_drivers = round(remaining_passengers / space_in_a_car + 0.5)
	
	print "To transport these people, we will need %s drivers and cars" % extra_drivers
	appr(average_passengers_per_car)
	
