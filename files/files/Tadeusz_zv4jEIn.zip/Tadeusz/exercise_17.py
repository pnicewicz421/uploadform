from sys import argv
from os.path import exists

script, from_file, to_file = argv

copydata = open(from_file).read()

print "We will copy the following data: %r" % copydata
print "From file: %r\nTo file: %r" % (from_file, to_file)

target = open(to_file, "r+")
target.truncate()
target.write(copydata)
print target.tell() #this tells us what position is.
target.seek (0,0) #this offsets the position. seek (offset, from), where 
				#offset is how many bytes from the position
				#from = 0 means the beggining,
				#from = 1 is current position
				#from = 2 is end of file
newdata = target.read()
print "This data now appears in the new file: %r" % newdata
target.close()

