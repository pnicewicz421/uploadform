class Room(object):

	def __init__(self, name, description):
		self.name = name
		self.description = description
		self.paths = {}
		self.actionset = {}
		
	def go(self, direction):
		return self.paths.get(direction, None)
		
	def add_paths(self, paths):
		self.paths.update(paths)
		
	def do_action(self, action):                         
		return self.actionset.get(action, None)
		
	def set_action(self, action):
		self.actionset.update(action)

class type_code(object):
	
	def enter(self):
		guesses = 3
		my_guess = 0 
		code = 2369
		print "You decide to come closer to the keypad."
		while my_guess <> guesses:
			print """The keypad screen message displays the following message:
					%d attempts left.""" % (guesses - my_guess)
			my_code = raw_input ("< ")
			if my_code == code:
				print "A message appears: Laser disabled."
				laser_disabled = True
				guesses = 3
			else:
				print "The keypad beeps."
		if laser_disabled:
			return east_room
		else:
			return death_room	
	

start_room = Room("Start Room", """You have entered the lobby of the art gallery. 
It is quiet and specks of dust settle down between the 
light beams entering in. A reception desk is visible, with the phone
blinking, but not much else. It is a very quiet day. You see
doorways on both the east and the west sides.""")

west_room = Room("West Room", """You see three baroque paintings of Mary Magdalene revering
Jesus, a stoic depiction of Peter betraying Jesus as the cock
crows, and a solemn, but sober crucifixion scene. You also
notice a keypad.""")

east_room = Room("East Room", """You have entered a room with a beautiful Medieval golden crucifix.""")

death_room = Room("Death Room", """You hear sirens approaching. You feel yourself being jammed against the wall,
hands handcuffed. The crucifix is left behind, glistening.""")

start_room.add_paths({'east': east_room,'west': west_room})
west_room.add_paths({'east': start_room})
east_room.add_paths({'west': start_room})

start_room.set_action({'type code': type_code()})

current_room = start_room

while current_room <> death_room:
	print "You are in the %s." % current_room.name
	print current_room.description
	my_action = raw_input("< ")
	if current_room.actionset.has_key(my_action):
		print "I DID UNDERSTAND"
		takeme = current_room.do_action
		current_room = takeme.enter
	else:
		print "I did not understand"
		
		
			


