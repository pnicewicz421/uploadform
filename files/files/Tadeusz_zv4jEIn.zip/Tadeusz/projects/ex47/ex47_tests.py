from nose.tools import *
from ex47.game import Room 

def test_room():
	gold = Room("GoldRoom",
				"""Gold is in the room. 
				    You can go north.""")
	assert_equal(gold.name, "GoldRoom")
	assert_equal(gold.paths, {})
	
def test_room_paths():
	center = Room("Center", "Test Room in Center")
	north = Room("North", "Test Room in North")
	south = Room("South", "Test Room in South")
	
	center.add_paths({"North" : north, "South" : south})
	assert_equal(center.go("North"), north)
	assert_equal(center.go("South"), south)
	
def test_map():
	start = Room("Start", "West or Down")
	west = Room("Trees", "Trees. Go East.")
	down = Room("Dungeon", "It's dark. Can go up.")
	
	start.add_paths({"West" : west, "Down" : down})
	west.add_paths({"East" : start})
	down.add_paths({"Up" : start})
	
	assert_equal(start.go("West"), west)
	assert_equal(start.go("West").go("East"), start)
	assert_equal(start.go("Down").go("Up"), start)
	
