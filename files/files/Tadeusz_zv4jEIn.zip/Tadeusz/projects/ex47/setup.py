try:
	from setuptools import setup
	print "Could reach setuptools"
except ImportError:
	from distutils.core import setup
	print "Got it from distutils.core"
	
config = {
	'description': 'My Projects',
	'author': 'Peter Nicewicz',
	'url': 'URL to get it at.',
	'download_url': 'Where to download it.',
	'author_email': 'peter.nicewicz@gmail.com',
	'version': '0.1',
	'install_requires': ['nose'],
	'packages': ['NAME'],
	'scripts': [],
	'name': 'projectname'
}

setup(**config)