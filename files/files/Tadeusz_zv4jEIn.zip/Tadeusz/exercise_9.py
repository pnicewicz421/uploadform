days = "Mon Tue Wed Thu Fri Sat Sun"
months = "Jan\nFeb\nMar\nApr\nMay\nJun\nJul\nAug"

print "Days: ", days
print "Months: ", months

print """
A 
B
V
D
sd
sd
"""