#!usr/bin/python
#If object oriented programming can effectively stimulate
#a finite state machine, then this example will serve as an illustration
#of this abstract concept through the implementation of a turnstyle.

#State - locked, unlocked (States)
#PassThrough - go through, be blocked (Methods/Attributes)
#InsertCoin - if enough - unlocked state, thank you (still unlocked)(Transition)

#State as a superclass
#Locked as a State
#	PassThrough method
#		Locked
#	InsertCoin method
#		Mechanism-enough
# 			Unlocked
#		Locked
#Unlocked as a State
#	PassThrough method
#		Otherside
#	InsertCoin
#		haha!
#		Unlocked
#	
#Otherside as State

class State(object):

	def __init__(self):
		self.minimum = 25
		self.coin = 0
		
class Locked(State):
	
	def PassThrough(self):
		print "It won't budge. Try inserting coins."
		return Locked()
		
	def InsertCoin(self):
		if myState.coin >= myState.minimum:
			print "You put the coin in and a green light flashes."
			return Unlocked()
		else:
			print "Insert %s more coins" % (myState.minimum - myState.coin)
			return Locked()

class Unlocked(State):
	
	def PassThrough(self):
		print "You push through the turn style."
		return "otherside"
		
	def InsertCoin(self):
		print "Thank you, but I don't need more coins. Try Walking through"
		return Unlocked()	

#class OtherSide(State):
#	def PassThrough(self):
#		print "You have made it to the other side."
#		exit(1)
		
myState = State()
current_state = Locked()

while (current_state != "otherside"):
	resp = int(raw_input("Do you 1) push through or 2) insert coin>"))
	if resp == 1:
		current_state = current_state.PassThrough()
	if resp == 2:
		coin = int(raw_input("How many (more) coins?>"))
		myState.coin += coin
		current_state = current_state.InsertCoin()

print "You have made it to the other side."