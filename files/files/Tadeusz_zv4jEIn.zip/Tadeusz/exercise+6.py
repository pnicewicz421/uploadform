x = "There are %d types of people" % 10
binary = "binary"
do_not = "don't"
y = "Those who know %s and those who %s." % (binary, do_not)

print "I said: %r." % x
print "I also said: '%s'." % y

hilarious = False #boolean
joke_eval = "Isn't that funny? %r" #boolean inside the string

print  joke_eval % hilarious

w = "This is the left side ..."
e = "and this is the right side."

print w + e 