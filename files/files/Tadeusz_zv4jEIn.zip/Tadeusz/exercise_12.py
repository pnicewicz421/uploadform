from sys import argv

n = len(argv)

needed = 4 - n

print "You've only provided %i arguments. We will need to ask about %i more." % (n, needed)

if n == 2:
	script, age = argv
if n == 3:
	script, age, height = argv
if n == 4:
	script, age, weight, height = argv

if needed >= 1:
	weight = raw_input("How much do you weigh? ")
	
if needed >= 2:
	height = raw_input("How tall are you? ")
	
if needed >= 3:
	age = raw_input("How old are you? ")
	
	
print "You are %s old %s tall and %s heavy." % (age, height, weight)