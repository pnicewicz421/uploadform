class Account(object): 
    counter = 0
    def __init__(self, holder, number, balance,credit_line=1500): 
        Account.counter += 1
        self.__Holder = holder 
        self.__Number = number 
        self.__Balance = balance
        self.__CreditLine = credit_line
    def __del__(self):
        Account.counter -= 1
        print "I've destroyed one instance"
        
print Account.counter

a1 = Account("Homer Simpson", 2893002, 2325.21)

print Account.counter

a2 = Account("Fred Flintstone", 2894117, 755.32)
print Account.counter

a3 = a2
print Account.counter

a4 = Account("Bill Gates", 2895007, 5234.32)
print Account.counter

del a4
print Account.counter

del a3
print Account.counter

del a2
print Account.counter
