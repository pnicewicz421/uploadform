from sys import argv

n = len(argv) 
print "You have %i arguments" % n

x= 1

for i in argv:
	print "Argument %i: %s\r" % (x, i)
	x = x + 1

#filename, first, second, third = argv

#print "The script: %s\nFirst: %s\nSecond: %s\nThird: %s" % (filename, first, second, third)