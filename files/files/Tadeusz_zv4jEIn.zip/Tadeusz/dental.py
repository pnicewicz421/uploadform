a = 1

if a != 1:
	print "Good job!"

	
print "No else!"