name = "Peter"
age = 29
height_inches = 67
height_cm = height_inches * 2.54
weight_lbs = 150
weight_kl = weight_lbs * 0.453592
eyes = "Black"
teeth = "White"
hair = "Black"

print "Let's talk about %r." % name
print "He is %s years old." % age
print "He is %s inches (%s centimeters) tall." % (height_inches, height_cm)
print "He weighs %s pounds (%s kilograms)." % (weight_lbs, weight_kl)
print "He has %s eyes and %s hair." % (eyes, hair)
print "He has %s teeth." % teeth


print "If I add %d, %d, and %d, I get %d" % (age, height_inches, weight_lbs, age + height_inches + weight_lbs)