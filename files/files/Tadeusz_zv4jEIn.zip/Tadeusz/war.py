#!/usr/bin/python
# -----WAR--------
# The point of this exercise is to create the card game war.
# What is needed:
# Class card is-a object
# Class card has-a rank from [2, 14] 
# Class card has-a suit from ["S", "H", "D", "C"]
# A deck is a class that has an ordered list of 52 cards 
# A hand is class an ordered list of 26 cards, alternating from the deck
# A hand has a number (count of items) that is counted at each play
# If a hand = 0 then that player loses
# Player 1 is an object of a hand
# Player 2 is an object of a hand
# A battle is a function that takes the "next" card from each player and 
# 1) discloses its rank and suit
# if player 1's card has a larger rank than player 2, then
# player 1's hand is appended to include player 1's card and player 2's card 
# (random which one comes first)
# if player 2's card has a larger rank than player 2 the,
# player 2's hand is appended to include player 2's card and player 1's card 
# (random which one comes first)
# if player 1's card's rank equals player 2's card's rank then function war
# war:
# player 1 card is still active
# player 1 "lays" 3 hands
# and then battles
# but collects all 10 cards at the end of the hand, in random order
# In this version, jokers do not exists


import random

def generate():

	deck = []

	for suit in ["C", "S", "H", "D"]:
		for rank in range(2, 15):
			deck.append((rank, suit)) 
	return deck
	
def shuffle(deck):
	
	random.shuffle(deck)
	print "DECK: ", deck
	print len(deck)
	return deck
	
def split(deck):
	
	player1 = []
	player2 = []
	n = 1
	for card in deck:
		if n % 2 == 1.0:
			player1.append(card)
		else:
			player2.append(card)
		n += 1
		
	return player1, player2
	
def battle(player1, player2, start):
	
	print "HAND 1:", player1[start[0]], "POSITION: ", start[0]
	print "HAND 2:", player2[start[1]], "POSITION: ", start[1]

	hand1 = player1[start[0]]
	hand2 = player2[start[1]]
	
	if hand1[0] > hand2[0]:
		
		print "PLAYER 1 WINS THIS BATTLE!"
		
		for i in range(0, start[0] + 1):
			player1.append(player1[i])
			print "I JUST ADDED: ", player1[i]
			print player1[i]
			print "I AM at position %s, hand: %s" % (i, player1[i])
		for i in range(0, start[0] + 1):
			player1.pop(0)
			
		for i in range(0, start[1] + 1):
			player1.append(player2[i])
			print "I JUST ADDED this hand to player 1 from player 2: ", player2[i]
		for i in range(0, start[1] + 1):
			player2.pop(0)

		print "PLAYER 1 has", len(player1), " cards"
		print "PLAYER 2 has", len(player2), " cards"
		
		war = False
		
	elif hand1[0] < hand2[0]:
		
		print "PLAYER 2 WINS THIS BATTLE!"
		
		for i in range(0, start[1] + 1):
			player2.append(player2[i])
			print "I JUST ADDED: ", player2[i]
		for i in range(0, start[1] + 1):
			player2.pop(0)
		for i in range(0, start[0] + 1):
			player2.append(player1[i])
			print "I JUST ADDED this hand to player 2 from player 1: ", player1[i]
		for i in range(0, start[0] + 1):
			player1.pop(0)
			
		
		print "PLAYER 1 has", len(player1), " cards"
		print "PLAYER 2 has", len(player2), " cards"
		
		war = False
	else:									# WAR!
		war = True
		
	return war
	
			
start = [0, 0]  #start measures the position number of the hands in battle (i.e., 0 for a battle,
		 	  #4, 8, 12, etc. for iterations of war

deck = generate()     #generates deck of cards
shuffle(deck)         #shuffles deck of cards	
player1, player2 = split(deck)	          #splits a deck of cards into two (or more down the line)
hand1 = []
hand2 = []
start = []
war = False

while len(player1) != 0 and len(player2) != 0:
	resp = raw_input("Press to play next hand> ")
	if war == True:
		print "---" *25
		print "WAR!!!"
		start = [start[0] + 4, start[1] + 4]
		if len(player1) - 1 < start[0]:
			start[0] = len(player1) - 1
			print "I AM AT POSITION: ", start[0]
		if len(player2) - 1 < start[1]:
			start[1] = len(player2) - 1
			print "I AM AT POSITION: ", start[1]
	else:
		start = [0, 0]
			
	hand1 = player1[start[0]]
	hand2 = player2[start[1]]
	
	war = False		
	war = battle(player1, player2, start)
	