ten_people = "Mama Papa Brother"

people = ten_people.split(' ')
people_bank = ["Sister", "Wife", "Cousin", "Uncle", "Aunt", "Grandma", "Grandpa", "Father-in-law", "Mother-in-law"]

print "There are %s in the family." % len(people)
print people
print "How many more would you like to add?" 

while True:
	resp = int(raw_input("> "))

	if 1 < resp <= len(people_bank):
		for i in range(1, resp+1):
			person = people_bank.pop()
			print "Adding: ", person
			people.append(person)
			print "There are %d people in the family now." % len(people)
		break
	else:
		print "You have to pick a number between 1 and %s" % len(people_bank)
	
print '*'.join(people[0:len(people)+1])
print people not in people_bank