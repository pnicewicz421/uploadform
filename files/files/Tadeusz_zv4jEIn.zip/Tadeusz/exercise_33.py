num = 6
numbers = []

def loopy(i):
	print "At the top i is %d" % i
	numbers.append(i)
	
	i += 1
	print "Numbers now: ", numbers
	print "At the bottom i is %d" % i
	
for i in range(0,num):
	loopy(i)
	
print "The numbers: "

for num in numbers:
	print num
	