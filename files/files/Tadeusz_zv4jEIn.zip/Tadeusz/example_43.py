class Scene(object):
	
	def _enter(self):
		print "We are in class scene, method enter"
		exit(1)
		
class Engine(object):

	def __init__(self, scene_map):
		self.scene_map = scene_map  #The variable scene_map of class Engine
									# variable is-a Map
	
	def play():
		current_scene = self.scene_map.opening_scene()    #Scene_Map = variable of class Map
		last_scene = self.scene_map.next_scene("finished")  
		
		while current_scene != last_scene:
			next_scene_name = self.current_scene.enter()    #
			current_scene = self.scene_map.next_scene(next_scene_name)
			
		current_scene.enter()

class Lobby(Scene):
	
	def enter(self):
		print "We are in the Lobby!"
		pass

class Capture(Scene):
	
	def _enter(self):
		print "We are captured!"
		pass

class Map(object):

	scenes = {
		'lobby': Lobby(),
		#'gallery': Gallery(),
		#'mechanical_room': MechanicalRoom(),
		'capture': Capture()
		#'finished': Finished()
	}
		
	def __init__(self, start_scene):
		self.start_scene = start_scene     #The variable start_scene of class Map
	
	def next_scene(self, scene_name):
		val = self.scenes.get(scene_name)
		return val
		
	def opening_scene(self):
		return self.next_scene(self.start_scene)
		
aMap = Map("lobby")   #Feed start_scene
Next_Scene = aMap.next_scene("capture")
Next_Scene._Capture__enter()

#aGame = Engine(aMap)    
#aGame.play()  
