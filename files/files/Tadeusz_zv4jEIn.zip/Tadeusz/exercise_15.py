from sys import argv

script, filename = argv

txt = open(filename)

print "Reading file: %r:" % filename
print txt.read()

print "Type a different file name: "
new_file = raw_input("> ")

txt_again = open(new_file)
print txt_again.read()