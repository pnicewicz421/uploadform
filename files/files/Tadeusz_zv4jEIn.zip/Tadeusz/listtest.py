a= [2, "bob"]

if 1 in a:
	print "1 is in a. i.e. key found at location ", a.index(1)
	location = a.index(1)
elif 1 not in a:
	print "1 is not found in a"
	a.append(1)
	location = len(a)-1
	print "I just added it to location ", location 
else:
	quit()
		
print "-" *25
print "Here is the list: ", a