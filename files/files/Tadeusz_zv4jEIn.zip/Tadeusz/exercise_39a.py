import hashmap

cities = hashmap.new()
hashmap.set(cities, 'CA', 'San Francisco')
hashmap.set(cities, 'CA', 'Detroit')




print "MI: ", hashmap.get(cities, 'MI')


#print "FL: ", hashmap.get(cities, 'FL')
#print "TX: ", hashmap.get(cities, 'TX')
#print "---" * 25
print "All cities:"
print hashmap.list(cities)