print "Moj syn bedzie sie nazywal Tadeusz."
print "Ale, jezeli to bedzie corka, to wtedy ona bedzie sie nazywala Izabela."
# print "Hello Again"
# print "I like typing this."
# print "This if fun."
# print 'Yay! Printing.'
# print "I'd much rather you 'not'."
# print 'I "said" do not touch this.'