from sys import exit
move = 0

def gold_room(move):
	print "This room is full of gold. How much do you take?"
	
	choice = raw_input(">" )
	move += 1
	if "0" in choice or "1" in choice:
		how_much = int(choice)
	else:
		dead("Learn to type a number.", move)
		
	if how_much < 50:
		print "Nice, you're not greedy, you won in %s moves." % move
		exit(0)
	else:
		dead("You greedy bastard!", move)
		
def bear_room(move):
	print "There is a bear here."
	print "The bear has a bunch of honey."
	print "The fat bear is in front of another door."
	print "How are you going to move the bear?"
	bear_moved = False
	
	
	while True:
		choice = raw_input("> ")
		move += 1
	
		if "take" in choice or "honey" in choice:
			dead("The bear looks at you then slap you.", move)
		elif "taunt" in choice or "bear" in choice and not bear_moved:
			print "The bear has moved from the door."
			bear_moved = True
		elif "taunt" in choice or "bear" in choice and bear_moved:
			dead("The bear gets pissed off and chews your head off.", move)
		elif choice == "open door" and bear_moved:
			gold_room(move)
		else:
			print "I have no idea what that means."

def cthulhu_room(move):
	print "Here you see the great evil Cthulhu."
	print "He, it, whatever, stares at you and you go inside."
	print "Do you feel for your life or eat your head?"
	
	choice = raw_input("> ")
	move += 1 
	
	if "flee" in choice:
		start(move)
	elif "head" in choice:
		dead("Well that was tasty!", move)
	else:
		cthulhu_room(move)

def north_room(move):
	print "You are now in a dark room"
	print "Do you walk ahead or do you stay close to the wall?"
	light = False
	
	while True:
		choice = raw_input("> ")
		move += 1
		
		if "walk" in choice or "ahead" in choice:
			dead("You walk into a hole in the middle of the room.", move)
		elif "close" in choice or "wall" in choice:
			print "You find a light switch."
			print "You turn it on."
			print "You see a hole in the middle of the room."
			print "You see a scroll on the other side of the hole."
			light = True
		elif "jump" in choice and light == False:
			dead("You plummet straight into your death.", move)
		elif "jump" in choice and light == True:
			print "You jump across."
			print "You pick up the magic scroll."
			print "Good job!"
			print "You won the game in %s moves" % move
			exit(0)
		else:
			print "I have no idea what that means."
	

def dead(why, move):
	print why, "Good job!"
	print "You lost the game in %s moves." % move
	exit(0)
	
def start(move):
	print "You are in a dark room."
	print "There is a door to your right and left or north."
	print "Which one do you take?"
	
	choice = raw_input("> ")
	move += 1
	
	if choice == "left":
		bear_room(move)
	elif choice == "right":
		cthulhu_room(move)
	elif choice == "north":
		north_room(move)
	else:
		dead("You stumble around the room until you starve", move)
		
move = 0	
start(move)
		